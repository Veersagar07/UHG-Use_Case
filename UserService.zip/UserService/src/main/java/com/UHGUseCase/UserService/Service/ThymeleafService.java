package com.UHGUseCase.UserService.Service;

import java.util.Map;

public interface ThymeleafService {
	String createContent(String template,Map<String,Object>variables);
}
