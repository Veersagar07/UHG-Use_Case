package com.UHGUseCase.UserService.Entity;

public enum ERole {
	
	ROLE_USER,
	ROLE_ADMIN
	
}